
checkpoint
pg_start_backup('hot_backup');

